﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class 柴胡数据查询导出系统 : Form
    {
        public 柴胡数据查询导出系统()
        {
            InitializeComponent();
        }
        private string userName = "sa";
        private string password = "YXW19941029";
        private string server = "172.16.1.121";
        private string connStr = "";
        private string sql = "";
        public SqlConnection conn = null;
        private void button1_Click(object sender, EventArgs e)
        {
            string ID = textBox1.Text.ToString().Trim();
            string medicine1 = textBox2.Text.ToString().Trim();
            string medicine2 = textBox3.Text.ToString().Trim();
            string medicine3 = textBox4.Text.ToString().Trim();
            string medicine4 = textBox5.Text.ToString().Trim();
            try
            {
                connStr = "server=" + server + ";uid=" + userName + ";pwd=" + password + ";database=gxbdb";
                conn = new SqlConnection(connStr);
                conn.Open();
                if (ID == "")
                {
                    sql = "select * from main where 方剂药物组成 like '%" + medicine1 + "%' and 方剂药物组成 like '%" + medicine2 + "%' and 方剂药物组成 like '%" + medicine3 + "%' and 方剂药物组成 like '%" + medicine4 + "%'";
                }
                else
                {
                    sql = "select * from main where ID=" + ID + " and 方剂药物组成 like '%" + medicine1 + "%' and 方剂药物组成 like '%" + medicine2 + "%' and 方剂药物组成 like '%" + medicine3 + "%' and 方剂药物组成 like '%" + medicine4 + "%'";
                }
                //sql = "select * from main";
                SqlCommand sc = new SqlCommand(sql, conn);
                SqlDataAdapter sda = new SqlDataAdapter(sc);
                DataSet ds = new DataSet();
                sda.Fill(ds, "main");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "main";
                conn.Close();
                conn.Dispose();
            }
            catch (Exception se)
            {
                MessageBox.Show("不能连接数据库，详细信息如下\n" + se.ToString());
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsNumber(e.KeyChar)) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }
    }
}
