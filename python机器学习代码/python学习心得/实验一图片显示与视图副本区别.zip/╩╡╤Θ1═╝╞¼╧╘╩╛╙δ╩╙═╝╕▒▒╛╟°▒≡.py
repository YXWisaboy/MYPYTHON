from scipy import misc
import matplotlib.pyplot as plt

l = misc.imread('Koala.jpg')
lcopy=l.copy()
lview=l.view()

plt.subplot(221)
plt.imshow(l)
plt.subplot(222)
plt.imshow(lcopy)
lview.flat=0
plt.subplot(223)
plt.imshow(lview)

plt.subplot(224)
plt.imshow(lview)
plt.show()
